package com.example.wordpicture

import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

// ---------- Colors (warm orange / leaf green / golden light) ----------
private val Sand = Color(0xFFFFEBD0)
private val Orange = Color(0xFFF28C28)
private val Ink = Color(0xFF3B2314)
private val Leaf = Color(0xFF3F8F55)
private val Gold = Color(0xFFFFC857)
private val Paper = Color(0xFFFFFBF4)
private val Wrong = Color(0xFFC0392B)

// ---------- Data ----------
enum class Lang(val label: String, val locale: Locale, val rtl: Boolean) {
    EN("English", Locale.forLanguageTag("en-US"), false),
    FA("فارسی", Locale.forLanguageTag("fa-IR"), true)
}

data class Item(val emoji: String, val en: String, val fa: String) {
    fun word(l: Lang): String = if (l == Lang.FA) fa else en
    fun other(l: Lang): String = if (l == Lang.FA) en else fa
}

val items = listOf(
    Item("🍎", "apple", "سیب"),
    Item("🐱", "cat", "گربه"),
    Item("☀️", "sun", "خورشید"),
    Item("📖", "book", "کتاب"),
    Item("🌳", "tree", "درخت"),
    Item("🏠", "house", "خانه"),
    Item("🐟", "fish", "ماهی"),
    Item("⭐", "star", "ستاره"),
    Item("🌙", "moon", "ماه"),
    Item("🍞", "bread", "نان"),
    Item("🍌", "banana", "موز"),
    Item("👟", "shoe", "کفش"),
    Item("🚗", "car", "ماشین"),
    Item("☕", "tea", "چای"),
    Item("🐦", "bird", "پرنده")
)

fun shuffleLetters(word: String): List<Char> {
    val letters = word.toList()
    if (letters.toSet().size <= 1) return letters
    var s = letters.shuffled()
    var guard = 0
    while (s == letters && guard < 20) {
        s = letters.shuffled()
        guard++
    }
    return s
}

// ---------- Activity (voice via the phone's own text-to-speech) ----------
class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        tts = TextToSpeech(this, this)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Orange,
                    onPrimary = Color.White,
                    background = Sand,
                    onBackground = Ink,
                    surface = Paper,
                    onSurface = Ink
                )
            ) {
                GameScreen(speak = { text, lang -> speak(text, lang) })
            }
        }
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
    }

    private fun speak(text: String, lang: Lang) {
        val engine = tts
        if (engine == null || !ttsReady) {
            toast("Voice engine is not ready yet")
            return
        }
        val result = engine.setLanguage(lang.locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            toast(if (lang == Lang.FA) "Persian voice is not installed on this phone" else "English voice is not installed on this phone")
            return
        }
        preferFemaleVoice(engine, lang)
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "word")
    }

    private fun preferFemaleVoice(engine: TextToSpeech, lang: Lang) {
        try {
            val candidates = engine.voices?.filter {
                it.locale.language == lang.locale.language &&
                    !it.isNetworkConnectionRequired &&
                    it.features?.contains("notInstalled") != true
            }
            val female = candidates?.firstOrNull { it.name.contains("female", ignoreCase = true) }
            if (female != null) engine.setVoice(female)
        } catch (e: Exception) {
            // keep the phone's default voice
        }
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

// ---------- UI ----------
@Composable
fun GameScreen(speak: (String, Lang) -> Unit) {
    var lang by remember { mutableStateOf(Lang.EN) }
    var index by remember { mutableIntStateOf(0) }

    val item = items[index]
    val word = item.word(lang)
    val n = word.length
    val isFa = lang == Lang.FA

    var tiles by remember(lang, index) { mutableStateOf(shuffleLetters(word)) }
    var used by remember(lang, index) { mutableStateOf(listOf<Int>()) }
    var solved by remember(lang, index) { mutableStateOf(false) }
    var wrong by remember(lang, index) { mutableStateOf(false) }

    val boxSize = when {
        n >= 6 -> 42.dp
        n == 5 -> 50.dp
        else -> 60.dp
    }
    val dir = if (lang.rtl) LayoutDirection.Rtl else LayoutDirection.Ltr

    fun show(c: Char): String = if (lang == Lang.EN) c.uppercaseChar().toString() else c.toString()

    fun pick(i: Int) {
        if (solved || i in used || used.size >= n) return
        val next = used + i
        used = next
        wrong = false
        if (next.size == n) {
            val attempt = next.map { tiles[it] }.joinToString("")
            if (attempt == word) solved = true else wrong = true
        }
    }

    fun undo() {
        if (solved || used.isEmpty()) return
        used = used.dropLast(1)
        wrong = false
    }

    fun reshuffle() {
        if (solved) return
        tiles = shuffleLetters(word)
        used = emptyList()
        wrong = false
    }

    fun hint() {
        if (solved) return
        var k = 0
        while (k < used.size && tiles[used[k]] == word[k]) k++
        val base = used.take(k)
        if (base.size >= n) return
        val need = word[base.size]
        val ti = tiles.indices.firstOrNull { it !in base && tiles[it] == need } ?: return
        val next = base + ti
        used = next
        wrong = false
        if (next.size == n) solved = true
    }

    LaunchedEffect(solved) {
        if (solved) speak(word, lang)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Sand)
            .systemBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("${index + 1} / ${items.size}", color = Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Lang.values().forEach { l ->
                    LangChip(l, selected = l == lang) { lang = l }
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        Box(
            modifier = Modifier
                .size(170.dp)
                .clip(CircleShape)
                .background(Orange),
            contentAlignment = Alignment.Center
        ) {
            Text(item.emoji, fontSize = 88.sp)
        }

        Spacer(Modifier.height(20.dp))

        CompositionLocalProvider(LocalLayoutDirection provides dir) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (pos in 0 until n) {
                    val ch = used.getOrNull(pos)?.let { tiles[it] }
                    Box(
                        modifier = Modifier
                            .size(boxSize)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                when {
                                    ch == null -> Orange.copy(alpha = 0.25f)
                                    solved -> Leaf
                                    else -> Gold
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (ch != null) {
                            Text(
                                show(ch),
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (solved) Color.White else Ink
                            )
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        val message = when {
            solved -> if (isFa) "آفرین!" else "Well done!"
            wrong -> if (isFa) "دوباره امتحان کن" else "Try again"
            else -> if (isFa) "حروف را به ترتیب بزن" else "Tap the letters in order"
        }
        Text(
            message,
            color = if (wrong) Wrong else if (solved) Leaf else Ink,
            fontSize = 18.sp,
            fontWeight = FontWeight.Medium
        )

        if (solved) {
            Spacer(Modifier.height(8.dp))
            CompositionLocalProvider(LocalLayoutDirection provides dir) {
                Text(word, fontSize = 36.sp, fontWeight = FontWeight.Bold, color = Ink)
            }
            Spacer(Modifier.height(10.dp))
            val otherLang = if (isFa) Lang.EN else Lang.FA
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionButton("🔊 " + (if (isFa) "تلفظ" else "Listen")) { speak(word, lang) }
                ActionButton("🔊 " + item.other(lang)) { speak(item.other(lang), otherLang) }
            }
        }

        Spacer(Modifier.weight(1f))

        CompositionLocalProvider(LocalLayoutDirection provides dir) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                tiles.forEachIndexed { i, c ->
                    val taken = i in used
                    Box(
                        modifier = Modifier
                            .size(boxSize)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (taken) Color.Transparent else Paper)
                            .border(
                                2.dp,
                                if (taken) Color.Transparent else Orange,
                                RoundedCornerShape(12.dp)
                            )
                            .clickable(enabled = !taken && !solved) { pick(i) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (!taken) {
                            Text(show(c), fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ink)
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (!solved) {
                ActionButton(if (isFa) "بُر زدن" else "Shuffle") { reshuffle() }
                ActionButton(if (isFa) "راهنما" else "Hint") { hint() }
                ActionButton(if (isFa) "پاک کردن" else "Undo") { undo() }
            } else {
                ActionButton(if (isFa) "بعدی" else "Next", primary = true) {
                    index = (index + 1) % items.size
                }
            }
        }

        Spacer(Modifier.height(8.dp))
    }
}

@Composable
fun ActionButton(text: String, primary: Boolean = false, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (primary) Leaf else Orange,
            contentColor = Color.White
        )
    ) {
        Text(text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun LangChip(l: Lang, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (selected) Orange else Paper)
            .border(2.dp, Orange, RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(
            l.label,
            color = if (selected) Color.White else Ink,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp
        )
    }
}
